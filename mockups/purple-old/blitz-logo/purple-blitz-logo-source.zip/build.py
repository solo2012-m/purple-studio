from pathlib import Path
import shutil, random
R=Path(__file__).parent
shutil.copy('/data/.openclaw/media/inbound/Purple_Blitz_logo_reference---5f660a97-f869-493e-b05a-743e8af4877a.png',R/'reference.png')
# Hand drawn outlines in reference image coordinates. Counters use evenodd fill.
purple=[
'M182 334 L216 238 L314 229 Q348 226 333 260 L326 277 Q320 292 293 295 L234 301 L224 329 Z M241 256 L235 278 L285 274 Q299 273 300 259 Q302 252 291 253 Z',
'M353 226 L387 223 L362 289 Q359 296 373 295 L401 292 Q414 291 418 280 L440 219 L472 216 L448 283 Q439 311 410 314 L354 319 Q321 320 329 294 Z',
'M483 216 L566 208 Q602 204 591 233 L584 253 Q579 267 553 271 L570 296 L536 300 L518 276 L495 278 L484 305 L451 309 Z M507 235 L500 255 L545 251 Q557 250 559 236 Q560 230 549 231 Z',
'M612 202 L691 193 Q730 189 716 224 L710 242 Q705 256 679 259 L628 265 L617 293 L581 297 Z M640 222 L633 242 L674 238 Q685 237 687 222 Q687 216 677 218 Z',
'M738 189 L774 185 L749 257 L813 250 L805 274 L705 284 Z',
'M850 172 L980 156 L971 179 L882 190 L875 209 L951 199 L943 220 L867 231 L860 248 L949 237 L940 262 L818 275 Z']
blit=[
'M284 346 L396 333 Q437 329 429 356 Q424 379 398 384 Q423 386 413 412 Q406 435 376 438 L246 452 Z M316 364 L309 383 L371 377 Q390 376 390 363 Q390 357 379 358 Z M301 402 L294 425 L361 418 Q378 416 378 405 Q379 398 365 400 Z',
'M458 328 L494 324 L465 409 L539 402 L529 430 L416 442 Z',
'M583 316 L622 312 L581 425 L541 431 Z',
'M635 313 L772 299 L762 326 L710 332 L680 418 L639 422 L672 336 L625 340 Z']
z='M794 301 L986 259 L824 398 L972 383 L785 456 L821 418 L672 485 L866 315 L759 333 Z'
def paths(items):return ''.join(f'<path d="{p}"/>' for p in items)
def solid(id,items,paint):
 p=paths(items)
 return f'<g id="{id}" fill-rule="evenodd"><g fill="#25064b" stroke="#400b78" stroke-width="2" transform="translate(10 8)">{p}</g><g fill="#63169e" transform="translate(5 4)">{p}</g><g fill="url(#{paint})" stroke="#ecd7ff" stroke-width="1.5" stroke-linejoin="round">{p}</g><g fill="none" stroke="#ae43ff" stroke-width=".7" transform="translate(0 2)">{p}</g></g>'
defs='''<defs><linearGradient id="silver" x1="0" y1="0" x2=".15" y2="1" objectBoundingBox="true"><stop stop-color="#fff"/><stop offset=".36" stop-color="#fffaff"/><stop offset=".49" stop-color="#dcd4ea"/><stop offset=".52" stop-color="#88739f"/><stop offset=".86" stop-color="#4a315f"/><stop offset="1" stop-color="#e1c8fa"/></linearGradient><linearGradient id="violet" x2=".1" y2="1"><stop stop-color="#fb9aff"/><stop offset=".35" stop-color="#d82dff"/><stop offset=".48" stop-color="#b919ed"/><stop offset=".5" stop-color="#7100b5"/><stop offset=".87" stop-color="#8d00ed"/><stop offset="1" stop-color="#fb91ff"/></linearGradient><linearGradient id="energy" x2=".4" y2="1"><stop stop-color="#fff"/><stop offset=".28" stop-color="#f2a0ff"/><stop offset=".49" stop-color="#a318ef"/><stop offset=".68" stop-color="#f5b2ff"/><stop offset="1" stop-color="#9600f5"/></linearGradient><filter id="bloom" x="-70%" y="-70%" width="240%" height="240%"><feGaussianBlur stdDeviation="5"/></filter><filter id="soft" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="12"/></filter></defs>'''
# Explicit coordinate gradients retain identical shading across every letter.
defs=defs.replace('x1="0" y1="0" x2=".15" y2="1" objectBoundingBox="true"','x1="0%" y1="0%" x2="12%" y2="100%"').replace('x2=".1" y2="1"','x2="8%" y2="100%"').replace('x2=".4" y2="1"','x2="30%" y2="100%"')
words=solid('purple',purple,'silver')+solid('blit',blit,'violet')
mark=solid('letter-z',[z],'energy')
veins='<g id="z-veins" fill="none" stroke="#fff3ff" stroke-linejoin="round"><path stroke-width="2.2" d="M976 264 L899 303 L918 300 L844 355 L866 352 L713 461 M850 354 L829 389 L862 402 L825 417 M899 303 L869 299 L819 317"/><path stroke-width=".9" d="M860 400 L907 395 L875 410 M843 356 L801 371 L791 387"/></g>'
glow=f'<g id="glow" fill="none" stroke="#d500ff" stroke-width="9" filter="url(#bloom)" opacity=".8">{paths(blit+[z])}</g>'
rng=random.Random(82)
def bolt(points):
 out=[points[0]]
 for a,b in zip(points,points[1:]):
  for i in range(1,8):
   t=i/8;out.append((a[0]+(b[0]-a[0])*t+rng.uniform(-10,10),a[1]+(b[1]-a[1])*t+rng.uniform(-5,5)))
  out.append(b)
 return 'M'+' L'.join(f'{x:.1f} {y:.1f}' for x,y in out)
bolts=[bolt([(1002,0),(945,76),(971,142),(927,205),(975,264)]),bolt([(927,205),(1047,173),(1090,214),(1200,180)]),bolt([(960,137),(864,106),(829,146)]),bolt([(975,264),(1025,338),(992,385),(1100,427),(1200,411)]),bolt([(846,356),(758,393),(726,453),(606,482)]),bolt([(1010,346),(1110,318),(1171,353)])]
arcpaths=paths(bolts)
arcs=f'<g id="discharges" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="#b000ff" stroke-width="12" filter="url(#bloom)">{arcpaths}</g><g stroke="#d763ff" stroke-width="3.5">{arcpaths}</g><g stroke="#fff5ff" stroke-width="1.2">{arcpaths}</g></g>'
def svg(body,view='135 125 925 395'):return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{view}" role="img" aria-label="Purple Blitz"><title>Purple Blitz</title>{defs}{body}</svg>'
(R/'logo.svg').write_text(svg(glow+words+mark+veins))
for name,body in [('purple',solid('purple',purple,'silver')),('blit',solid('blit',blit,'violet')),('z',mark+veins),('discharges',arcs),('glow',glow)]: (R/(name+'.svg')).write_text(svg(body,'0 0 1200 600'))
(R/'scene.svg').write_text(svg(glow+words+mark+veins+arcs,'0 0 1200 600'))
(R/'scene-inline.txt').write_text(svg(glow+words+mark+veins+arcs,'0 0 1200 600'))
